module.exports=[77950,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_simulasi-kpr_page_actions_263be4be.js.map