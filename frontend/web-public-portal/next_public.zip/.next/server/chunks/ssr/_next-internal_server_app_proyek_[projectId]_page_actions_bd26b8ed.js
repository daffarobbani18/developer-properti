module.exports=[14001,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_proyek_%5BprojectId%5D_page_actions_bd26b8ed.js.map