module.exports=[88568,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_proyek_%5BprojectId%5D_tipe_%5BtipeId%5D_page_actions_dff516ea.js.map