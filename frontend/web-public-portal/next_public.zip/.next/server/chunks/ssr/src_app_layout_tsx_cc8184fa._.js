module.exports=[27572,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("html",{lang:"id",children:(0,b.jsx)("body",{children:a})})}a.s(["default",()=>c,"metadata",0,{title:"SIMDP | Web Publik & Portal Customer",description:"Landing marketing dan portal customer untuk Ekosistem Digital Properti Terpadu"}])}];

//# sourceMappingURL=src_app_layout_tsx_cc8184fa._.js.map