module.exports=[41118,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_kontak_page_actions_eb2e4622.js.map