:HL["/_next/static/chunks/cc50dd2ea6730c05.css","style"]
0:{"buildId":"_4-SwzglpNHFmuy75Ef5x","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
